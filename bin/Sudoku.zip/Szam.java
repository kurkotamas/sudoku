
public class Szam {
	int ertek;
	boolean vedett;
	
	public Szam(int ertek, boolean vedett) {
		this.ertek = ertek;
		this.vedett = vedett;
	}
}
