
public class Main {
	public static void main(String args[]) throws InterruptedException {
		Sudoku sudoku = new Sudoku();
		sudoku.hozzaad(0, 0, 5);
		sudoku.hozzaad(0, 1, 3);
		sudoku.hozzaad(0, 4, 7);
		sudoku.hozzaad(1, 3, 1);
		sudoku.hozzaad(1, 4, 9);
		sudoku.hozzaad(1, 5, 5);
		sudoku.hozzaad(2, 1, 9);
		sudoku.hozzaad(2, 2, 8);
		sudoku.hozzaad(2, 7, 6);
		sudoku.hozzaad(1, 0, 6);	
		
		sudoku.hozzaad(3, 0, 8);
		sudoku.hozzaad(3, 4, 6);
		sudoku.hozzaad(3, 8, 3);
		sudoku.hozzaad(4, 0, 4);
		sudoku.hozzaad(4, 3, 8);
		sudoku.hozzaad(4, 5, 3);
		sudoku.hozzaad(4, 8, 1);
		sudoku.hozzaad(5, 0, 7);
		sudoku.hozzaad(5, 4, 2);
		sudoku.hozzaad(5, 8, 6);
		
		sudoku.hozzaad(6, 1, 6);
		sudoku.hozzaad(6, 6, 2);
		sudoku.hozzaad(6, 7, 8);
		sudoku.hozzaad(7, 3, 4);
		sudoku.hozzaad(7, 4, 1);
		sudoku.hozzaad(7, 5, 9);
		sudoku.hozzaad(7, 8, 5);
		sudoku.hozzaad(8, 4, 8);
		sudoku.hozzaad(8, 7, 7);
		sudoku.hozzaad(8, 8, 9);
//		
		
		sudoku.kiir();
		sudoku.kitolt(0, 0);
	}
}
